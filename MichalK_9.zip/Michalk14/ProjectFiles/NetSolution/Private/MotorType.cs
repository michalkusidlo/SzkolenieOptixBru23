using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

[MapType(NamespaceUri = "Michalk14", Guid = "3de32eb29cd771a534a356b25d33e37a")]
public class MotorType : UAObject
{
#region Children properties
    //-------------------------------------------
    // WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
    //-------------------------------------------
    public int Power
    {
        get
        {
            return (int)Refs.GetVariable("Power").Value.Value;
        }
        set
        {
            Refs.GetVariable("Power").SetValue(value);
        }
    }
    public IUAVariable PowerVariable
    {
        get
        {
            return (IUAVariable)Refs.GetVariable("Power");
        }
    }
    public int Speed
    {
        get
        {
            return (int)Refs.GetVariable("Speed").Value.Value;
        }
        set
        {
            Refs.GetVariable("Speed").SetValue(value);
        }
    }
    public IUAVariable SpeedVariable
    {
        get
        {
            return (IUAVariable)Refs.GetVariable("Speed");
        }
    }
    public bool Enable
    {
        get
        {
            return (bool)Refs.GetVariable("Enable").Value.Value;
        }
        set
        {
            Refs.GetVariable("Enable").SetValue(value);
        }
    }
    public IUAVariable EnableVariable
    {
        get
        {
            return (IUAVariable)Refs.GetVariable("Enable");
        }
    }
#endregion
}
