using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

namespace Michalk14
{
    public static class ObjectTypes
    {
        private static readonly int namespaceIndex = NamespaceMapProvider.GetNamespaceIndex("Michalk14");
        public static readonly NodeId MainWindow = new NodeId(namespaceIndex, new Guid("9fcdc2a0b607a8075a6596bd2b4904a5"));
        public static readonly NodeId Panel4 = new NodeId(namespaceIndex, new Guid("db976c5ca5a4a8a852be018df9e60837"));
        public static readonly NodeId EditUserDetailPanel = new NodeId(namespaceIndex, new Guid("5bd1738d3f60d47ba30b9df411fa0050"));
        public static readonly NodeId MotorType = new NodeId(namespaceIndex, new Guid("3de32eb29cd771a534a356b25d33e37a"));
        public static readonly NodeId Panel3 = new NodeId(namespaceIndex, new Guid("20686e21976e5cc2d739fde4d2d52df2"));
        public static readonly NodeId Panel1 = new NodeId(namespaceIndex, new Guid("c95c72899bbc5d9071c807e5d918a397"));
        public static readonly NodeId Login = new NodeId(namespaceIndex, new Guid("ce814fddddd607c776a3b9a6e0b90c27"));
        public static readonly NodeId Panel2 = new NodeId(namespaceIndex, new Guid("d8d9e8c22d51ecfc87e628ea60097815"));
        public static readonly NodeId Panel5 = new NodeId(namespaceIndex, new Guid("e13082cb1e10fbb1bbc6956194ce8bed"));
        public static readonly NodeId Panel_Motor = new NodeId(namespaceIndex, new Guid("c1a9e1d1133ceb8ed041b0ac3bc8f51e"));
        public static readonly NodeId Panel6 = new NodeId(namespaceIndex, new Guid("c5472e5a85105359bf9cfe2e3d1cf79d"));
        public static readonly NodeId Panel7 = new NodeId(namespaceIndex, new Guid("5e2468cfd4b06bcc958342f67991da15"));
        public static readonly NodeId Panel8 = new NodeId(namespaceIndex, new Guid("c1e1b90b22e2e79ff87cc358476b2ab5"));
        public static readonly NodeId Panel9 = new NodeId(namespaceIndex, new Guid("a8fcc1e766c11359c5bdfef064efc0d4"));
        public static readonly NodeId DialogBox1 = new NodeId(namespaceIndex, new Guid("afad0e669a5b539fb6296335c106c43c"));
        public static readonly NodeId Panel10 = new NodeId(namespaceIndex, new Guid("4cb07e3e74437771705717ce0b95a207"));
        public static readonly NodeId ChangeUserForm = new NodeId(namespaceIndex, new Guid("aafae88a96cb862a3d9a244021075150"));
        public static readonly NodeId ChangeUserPasswordExpiredDialog = new NodeId(namespaceIndex, new Guid("fdec4df0661b496689dfbf9cfcb33ae1"));
        public static readonly NodeId ChangeUserChangePasswordForm = new NodeId(namespaceIndex, new Guid("e98f071e78271b043e525124cfadd8f9"));
        public static readonly NodeId LoginForm = new NodeId(namespaceIndex, new Guid("d0fba00ff93f064d6e1cb546eea27209"));
        public static readonly NodeId LoginPasswordExpiredDialog = new NodeId(namespaceIndex, new Guid("53b1bd1b17b4de66926108a7dfdf143e"));
        public static readonly NodeId Logout = new NodeId(namespaceIndex, new Guid("2eebfd3def044e747aa57952fc13c70d"));
        public static readonly NodeId LoginChangePasswordForm = new NodeId(namespaceIndex, new Guid("fc0d46c3cf6fc6f7faace8fa13bde2b5"));
        public static readonly NodeId DialogBoxLogin = new NodeId(namespaceIndex, new Guid("6271dfbce66bc16e0951100896e83da8"));
        public static readonly NodeId UserEditorOverview = new NodeId(namespaceIndex, new Guid("fd52139656c4cab63738095f771343a3"));
        public static readonly NodeId NoUsersPanel = new NodeId(namespaceIndex, new Guid("638838acd9f5ae93ca75b058c300b43b"));
        public static readonly NodeId LocaleComboBox = new NodeId(namespaceIndex, new Guid("b6239b77b31bba48a937ee481e521c37"));
        public static readonly NodeId GroupsPanel = new NodeId(namespaceIndex, new Guid("d312f5365c7d886a7a689a7c61bf2412"));
        public static readonly NodeId GroupCheckbox = new NodeId(namespaceIndex, new Guid("937bdaeca748212659105fb563595c0b"));
        public static readonly NodeId GroupLabel = new NodeId(namespaceIndex, new Guid("59f233a86b88133bc07cecf82da51463"));
        public static readonly NodeId CreateUserPanel = new NodeId(namespaceIndex, new Guid("76c6b9dc24666b9297ce397d3fb2b9fe"));
    }

    public static class VariableTypes
    {
        private static readonly int namespaceIndex = NamespaceMapProvider.GetNamespaceIndex("Michalk14");
    }
}
