using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

[MapType(NamespaceUri = "Michalk11", Guid = "9fcdc2a0b607a8075a6596bd2b4904a5")]
public class MainWindow : FTOptix.UI.Window
{
}

[MapType(NamespaceUri = "Michalk11", Guid = "db976c5ca5a4a8a852be018df9e60837")]
public class Panel4 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk11", Guid = "20686e21976e5cc2d739fde4d2d52df2")]
public class Panel3 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk11", Guid = "c95c72899bbc5d9071c807e5d918a397")]
public class Panel1 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk11", Guid = "d8d9e8c22d51ecfc87e628ea60097815")]
public class Panel2 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk11", Guid = "e13082cb1e10fbb1bbc6956194ce8bed")]
public class Panel5 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk11", Guid = "c1a9e1d1133ceb8ed041b0ac3bc8f51e")]
public class Panel_Motor : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk11", Guid = "c5472e5a85105359bf9cfe2e3d1cf79d")]
public class Panel6 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk11", Guid = "5e2468cfd4b06bcc958342f67991da15")]
public class Panel7 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk11", Guid = "c1e1b90b22e2e79ff87cc358476b2ab5")]
public class Panel8 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk11", Guid = "afad0e669a5b539fb6296335c106c43c")]
public class DialogBox1 : FTOptix.UI.Dialog
{
}

[MapType(NamespaceUri = "Michalk11", Guid = "a8fcc1e766c11359c5bdfef064efc0d4")]
public class Panel9 : FTOptix.UI.Panel
{
}
