using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

namespace Michalk11
{
    public static class ObjectTypes
    {
        private static readonly int namespaceIndex = NamespaceMapProvider.GetNamespaceIndex("Michalk11");
        public static readonly NodeId MainWindow = new NodeId(namespaceIndex, new Guid("9fcdc2a0b607a8075a6596bd2b4904a5"));
        public static readonly NodeId Panel4 = new NodeId(namespaceIndex, new Guid("db976c5ca5a4a8a852be018df9e60837"));
        public static readonly NodeId MotorType = new NodeId(namespaceIndex, new Guid("3de32eb29cd771a534a356b25d33e37a"));
        public static readonly NodeId Panel3 = new NodeId(namespaceIndex, new Guid("20686e21976e5cc2d739fde4d2d52df2"));
        public static readonly NodeId Panel1 = new NodeId(namespaceIndex, new Guid("c95c72899bbc5d9071c807e5d918a397"));
        public static readonly NodeId Panel2 = new NodeId(namespaceIndex, new Guid("d8d9e8c22d51ecfc87e628ea60097815"));
        public static readonly NodeId Panel5 = new NodeId(namespaceIndex, new Guid("e13082cb1e10fbb1bbc6956194ce8bed"));
        public static readonly NodeId Panel_Motor = new NodeId(namespaceIndex, new Guid("c1a9e1d1133ceb8ed041b0ac3bc8f51e"));
        public static readonly NodeId Panel6 = new NodeId(namespaceIndex, new Guid("c5472e5a85105359bf9cfe2e3d1cf79d"));
        public static readonly NodeId Panel7 = new NodeId(namespaceIndex, new Guid("5e2468cfd4b06bcc958342f67991da15"));
        public static readonly NodeId Panel8 = new NodeId(namespaceIndex, new Guid("c1e1b90b22e2e79ff87cc358476b2ab5"));
        public static readonly NodeId DialogBox1 = new NodeId(namespaceIndex, new Guid("afad0e669a5b539fb6296335c106c43c"));
        public static readonly NodeId Panel9 = new NodeId(namespaceIndex, new Guid("a8fcc1e766c11359c5bdfef064efc0d4"));
    }

    public static class VariableTypes
    {
        private static readonly int namespaceIndex = NamespaceMapProvider.GetNamespaceIndex("Michalk11");
    }
}
