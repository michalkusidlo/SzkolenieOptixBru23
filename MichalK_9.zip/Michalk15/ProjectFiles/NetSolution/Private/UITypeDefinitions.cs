using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

[MapType(NamespaceUri = "Michalk15", Guid = "9fcdc2a0b607a8075a6596bd2b4904a5")]
public class MainWindow : FTOptix.UI.Window
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "db976c5ca5a4a8a852be018df9e60837")]
public class Panel4 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "5bd1738d3f60d47ba30b9df411fa0050")]
public class EditUserDetailPanel : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "20686e21976e5cc2d739fde4d2d52df2")]
public class Panel3 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "c95c72899bbc5d9071c807e5d918a397")]
public class Panel1 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "ce814fddddd607c776a3b9a6e0b90c27")]
public class Login : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "d8d9e8c22d51ecfc87e628ea60097815")]
public class Panel2 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "e13082cb1e10fbb1bbc6956194ce8bed")]
public class Panel5 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "c1a9e1d1133ceb8ed041b0ac3bc8f51e")]
public class Panel_Motor : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "62cba38d109d35f4d350d4da01c85917")]
public class Panel11 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "c5472e5a85105359bf9cfe2e3d1cf79d")]
public class Panel6 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "5e2468cfd4b06bcc958342f67991da15")]
public class Panel7 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "c1e1b90b22e2e79ff87cc358476b2ab5")]
public class Panel8 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "a8fcc1e766c11359c5bdfef064efc0d4")]
public class Panel9 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "4cb07e3e74437771705717ce0b95a207")]
public class Panel10 : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "aafae88a96cb862a3d9a244021075150")]
public class ChangeUserForm : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "fdec4df0661b496689dfbf9cfcb33ae1")]
public class ChangeUserPasswordExpiredDialog : FTOptix.UI.Dialog
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "e98f071e78271b043e525124cfadd8f9")]
public class ChangeUserChangePasswordForm : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "d0fba00ff93f064d6e1cb546eea27209")]
public class LoginForm : FTOptix.UI.PanelLoader
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "fd52139656c4cab63738095f771343a3")]
public class UserEditorOverview : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "638838acd9f5ae93ca75b058c300b43b")]
public class NoUsersPanel : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "d312f5365c7d886a7a689a7c61bf2412")]
public class GroupsPanel : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "937bdaeca748212659105fb563595c0b")]
public class GroupCheckbox : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "59f233a86b88133bc07cecf82da51463")]
public class GroupLabel : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "76c6b9dc24666b9297ce397d3fb2b9fe")]
public class CreateUserPanel : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "b6239b77b31bba48a937ee481e521c37")]
public class LocaleComboBox : FTOptix.UI.ComboBox
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "afad0e669a5b539fb6296335c106c43c")]
public class DialogBox1 : FTOptix.UI.Dialog
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "6271dfbce66bc16e0951100896e83da8")]
public class DialogBoxLogin : FTOptix.UI.Dialog
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "53b1bd1b17b4de66926108a7dfdf143e")]
public class LoginPasswordExpiredDialog : FTOptix.UI.Dialog
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "2eebfd3def044e747aa57952fc13c70d")]
public class Logout : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "Michalk15", Guid = "fc0d46c3cf6fc6f7faace8fa13bde2b5")]
public class LoginChangePasswordForm : FTOptix.UI.Panel
{
}
