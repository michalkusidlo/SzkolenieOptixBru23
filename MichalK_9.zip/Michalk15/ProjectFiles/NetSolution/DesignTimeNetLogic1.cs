#region Using directives
using System;
using UAManagedCore;
using OpcUa = UAManagedCore.OpcUa;
using FTOptix.HMIProject;
using FTOptix.Alarm;
using FTOptix.UI;
using FTOptix.NativeUI;
using FTOptix.WebUI;
using FTOptix.CoreBase;
using FTOptix.Recipe;
using FTOptix.DataLogger;
using FTOptix.EventLogger;
using FTOptix.SQLiteStore;
using FTOptix.Store;
using FTOptix.RAEtherNetIP;
using FTOptix.Retentivity;
using FTOptix.CommunicationDriver;
using FTOptix.NetLogic;
using FTOptix.AuditSigning;
using FTOptix.Core;
using FTOptix.OPCUAServer;
using FTOptix.Report;
#endregion

public class DesignTimeNetLogic1 : BaseNetLogic
{
    [ExportMethod]
    public void Method1CreateSimpleVariable()
    {
        var myfolder = Project.Current.Get<Folder>("Model/Variables");
        if (myfolder!=null)

        {
            myfolder.Delete();
        }
        myfolder = InformationModel.Make<Folder>("Variables");
        Project.Current.Get("Model").Add(myfolder);
        for (int i=1; i<=3; i++)
        {
            var myVar = InformationModel.MakeVariable("Variable" + i, OpcUa.DataTypes.UInt16);
            myfolder.Add(myVar);
        }
        // Insert code to be executed by the method
    }
}
